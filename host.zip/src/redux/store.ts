
import { configureStore } from "@reduxjs/toolkit";
import { pubilicApi } from "cart/pubilicApi"
import { cartApi } from "cart/cartApi"
import { authApi } from "auth/authApi"
import { addressApi } from "auth/addressApi"
import { orderApi } from "order/redux/order.api"
import { adminApi } from "admin/adminApi"
import authSlice from "auth/authSlice"

console.log(adminApi, "adminAPi");




const reduxStore = configureStore({
    reducer: {
        [pubilicApi.reducerPath]: pubilicApi.reducer,
        [cartApi.reducerPath]: cartApi.reducer,
        [authApi.reducerPath]: authApi.reducer,
        [orderApi.reducerPath]: orderApi.reducer,
        [addressApi.reducerPath]: addressApi.reducer,
        [adminApi.reducerPath]: adminApi.reducer,
        auth: authSlice


    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(pubilicApi.middleware, cartApi.middleware, authApi.middleware, addressApi.middleware, orderApi.middleware, adminApi.middleware),
})

export type RootState = ReturnType<typeof reduxStore.getState>
export type AppDispatch = typeof reduxStore.dispatch

export default reduxStore